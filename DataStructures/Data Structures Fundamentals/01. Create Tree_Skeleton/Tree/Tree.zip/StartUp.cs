﻿namespace Tree
{
    public static class StartUp
    {
        static void Main()
        {

        }
    }
}
