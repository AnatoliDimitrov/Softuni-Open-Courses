﻿using System.ComponentModel.Design.Serialization;
using System.Linq;

namespace _01.Hierarchy
{
    using System;
    using System.Collections.Generic;
    using System.Collections;

    public class Hierarchy<T> : IHierarchy<T>
    {
        private Node<T> root;
        private Dictionary<T, Node<T>> nodes;

        public Hierarchy(T element)
        {
            this.root = new Node<T>(element);
            this.nodes = new Dictionary<T, Node<T>> {{element, root}};
        }

        public int Count => this.nodes.Count;

        public void Add(T element, T child)
        {
            if (!this.nodes.ContainsKey(element))
            {
                throw new ArgumentException();
            }

            if (this.nodes.ContainsKey(child))
            {
                throw new ArgumentException();
            }

            var childNode = new Node<T>(child, this.nodes[element]);

            this.nodes.Add(child, childNode);

            this.nodes[element].Children.Add(childNode);
        }

        public void Remove(T element)
        {
            if (!this.nodes.ContainsKey(element))
            {
                throw new ArgumentException();
            }

            if (element.Equals(this.root.Value))
            {
                throw new InvalidOperationException();
            }

            var node = nodes[element];
            var parent = node.Parent;

            foreach (var child in node.Children)
            {
                parent.Children.Add(child);
                child.Parent = parent;
            }

            parent.Children.Remove(node);
            nodes.Remove(element);
        }

        public IEnumerable<T> GetChildren(T element)
        {
            if (!this.nodes.ContainsKey(element))
            {
                throw new ArgumentException();
            }

            List<T> result = new List<T>();

            foreach (var child in this.nodes[element].Children)
            {
                    result.Add(child.Value);
            }

            return result;
        }

        public T GetParent(T element)
        {
            if (!this.nodes.ContainsKey(element))
            {
                throw new ArgumentException();
            }

            var node = this.nodes[element];

            if (node.Parent == null)
            {
                return default;
            }

            return node.Parent.Value;
        }

        public bool Contains(T element)
        {
            return this.nodes.ContainsKey(element);
        }

        public IEnumerable<T> GetCommonElements(Hierarchy<T> other)
        {
            var result = new List<T>();

            foreach (var el in this.nodes)
            {
                if (other.Contains(el.Key))
                {
                    result.Add(el.Key);
                }
            }

            return result;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Queue<Node<T>> queue = new Queue<Node<T>>();

            queue.Enqueue(this.root);

            while (queue.Count > 0)
            {
                var current = queue.Dequeue();

                yield return current.Value;

                foreach (var child in current.Children)
                {
                    queue.Enqueue(child);
                }
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}