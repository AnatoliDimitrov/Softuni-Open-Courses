using System.Linq;

namespace _01.RoyaleArena
{
    using System;
    using System.Collections;
    using System.Collections.Generic;

    public class RoyaleArena : IArena
{
    private Dictionary<int, BattleCard> ids;
    private Dictionary<CardType, LinkedList<BattleCard>> types;
    private Dictionary<string, HashSet<BattleCard>> names;
    //private Dictionary<double, HashSet<Battlecard>> swag;

    public RoyaleArena()
    {
        this.ids = new Dictionary<int, BattleCard>();
        this.types = new Dictionary<CardType, LinkedList<BattleCard>>();
        this.names = new Dictionary<string, HashSet<BattleCard>>();
        //this.swag = new Dictionary<double, HashSet<Battlecard>>();
    }

    public void Add(BattleCard card)
    {
        this.ids[card.Id] = card;

        if (!this.types.ContainsKey(card.Type))
        {
            this.types[card.Type] = new LinkedList<BattleCard>();
        }

        this.types[card.Type].AddLast(card);

        if (!this.names.ContainsKey(card.Name))
        {
            this.names[card.Name] = new HashSet<BattleCard>();
        }

        this.names[card.Name].Add(card);

        //if (!this.swag.ContainsKey(card.Swag))
        //{
        //    this.swag[card.Swag] = new HashSet<Battlecard>();
        //}

        //this.swag[card.Swag].Add(card);
    }

    public bool Contains(BattleCard card)
    {
        return this.ids.ContainsKey(card.Id);
    }

    public int Count => this.ids.Count;

    public void ChangeCardType(int id, CardType type)
    {
        if (!this.ids.ContainsKey(id))
        {
            throw new ArgumentException();
        }

        var card = this.ids[id];

        types[card.Type].Remove(card);

        card.Type = type;

        if (!this.types.ContainsKey(type))
        {
            this.types[type] = new LinkedList<BattleCard>();
        }

        this.types[type].AddLast(card);
    }

    public BattleCard GetById(int id)
    {
        if (!this.ids.ContainsKey(id))
        {
            throw new InvalidOperationException();
        }

        return this.ids[id];
    }

    public void RemoveById(int id)
    {
        if (!this.ids.ContainsKey(id))
        {
            throw new InvalidOperationException();
        }

        var card = this.ids[id];

        this.ids.Remove(id);

        this.types[card.Type].Remove(card);

        this.names[card.Name].Remove(card);
    }

    public IEnumerable<BattleCard> GetByCardType(CardType type)
    {
        if (!this.types.ContainsKey(type) || this.types[type].Count == 0)
        {
            throw new InvalidOperationException();
        }

        return this.types[type]
            .OrderByDescending(c => c.Damage)
            .ThenBy(c => c.Id);
    }

    public IEnumerable<BattleCard> GetByTypeAndDamageRangeOrderedByDamageThenById(CardType type, int lo, int hi)
    {
        if (!this.types.ContainsKey(type) || this.types[type].Count == 0)
        {
            throw new InvalidOperationException();
        }

        return this.types[type]
            .Where(k => k.Damage > lo && k.Damage <= hi)
            .OrderByDescending(c => c.Damage)
            .ThenBy(c => c.Id);
    }

    public IEnumerable<BattleCard> GetByCardTypeAndMaximumDamage(CardType type, double damage)
    {
        if (!this.types.ContainsKey(type) || this.types[type].Count == 0)
        {
            throw new InvalidOperationException();
        }

        return this.types[type]
            .Where(k => k.Damage <= damage)
            .OrderByDescending(c => c.Damage)
            .ThenBy(c => c.Id);
    }

    public IEnumerable<BattleCard> GetByNameOrderedBySwagDescending(string name)
    {
        if (!this.names.ContainsKey(name))
        {
            throw new InvalidOperationException();
        }

        return this.names[name]
            .OrderByDescending(c => c.Swag)
            .ThenBy(c => c.Id);
    }

    public IEnumerable<BattleCard> GetByNameAndSwagRange(string name, double lo, double hi)
    {
        if (!this.names.ContainsKey(name))
        {
            throw new InvalidOperationException();
        }

        return this.names[name]
            .Where(c => c.Swag >= lo && c.Swag < hi)
            .OrderByDescending(c => c.Swag)
            .ThenBy(c => c.Id);
    }

    public IEnumerable<BattleCard> GetAllByNameAndSwag()
    {
        var list = new List<BattleCard>();

        foreach (var kvp in this.names)
        {
            list.Add(this.names[kvp.Key].OrderByDescending(c => c.Swag).First());
        }

        if (list.Count == 0)
        {
            return new List<BattleCard>();
            //throw  new InvalidOperationException();
        }

        return list;
    }

    public IEnumerable<BattleCard> FindFirstLeastSwag(int n)
    {
        if (n > this.ids.Count)
        {
            throw new InvalidOperationException();
        }

        return this.ids
            .Select(k => k.Value)
            .OrderBy(c => c.Swag)
            .ThenBy(c => c.Id)
            .Take(n);
    }

    public IEnumerable<BattleCard> GetAllInSwagRange(double lo, double hi)
    {
        return this.ids
            .Select(k => k.Value)
            .Where(c => c.Swag >= lo && c.Swag <= hi)
            .OrderBy(c => c.Swag);
    }

    public IEnumerator<BattleCard> GetEnumerator()
    {
        foreach (var kvp in this.ids)
        {
            yield return kvp.Value;
        }
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return this.GetEnumerator();
    }
}
}